package K23CNT3_TranThanhTung_WebBanDienThoai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23Cnt3TranThanhTungWebBanDienThoaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
