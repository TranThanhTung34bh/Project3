package K23CNT3_TranThanhTung_WebBanDienThoai.repository;

import K23CNT3_TranThanhTung_WebBanDienThoai.entity.TttChiTietHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TttChiTietHoaDonRepository extends JpaRepository<TttChiTietHoaDon, Integer> {
}
