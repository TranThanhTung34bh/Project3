package K23CNT3_TranThanhTung_WebBanDienThoai.repository;

import K23CNT3_TranThanhTung_WebBanDienThoai.entity.TttDanhMucSP;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TttDanhMucSPRepository extends JpaRepository<TttDanhMucSP, Integer> {
}
