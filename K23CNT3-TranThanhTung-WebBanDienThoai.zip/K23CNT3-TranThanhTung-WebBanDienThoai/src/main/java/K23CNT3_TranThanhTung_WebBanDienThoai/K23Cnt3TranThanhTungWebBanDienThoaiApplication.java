package K23CNT3_TranThanhTung_WebBanDienThoai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3TranThanhTungWebBanDienThoaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3TranThanhTungWebBanDienThoaiApplication.class, args);
	}

}
