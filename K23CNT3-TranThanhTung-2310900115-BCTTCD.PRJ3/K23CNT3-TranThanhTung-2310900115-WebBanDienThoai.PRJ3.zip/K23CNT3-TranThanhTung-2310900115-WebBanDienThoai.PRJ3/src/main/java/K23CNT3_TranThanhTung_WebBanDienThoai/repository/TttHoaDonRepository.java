package K23CNT3_TranThanhTung_WebBanDienThoai.repository;

import K23CNT3_TranThanhTung_WebBanDienThoai.entity.TttHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TttHoaDonRepository extends JpaRepository<TttHoaDon, Integer> {
}
