package k23cnt3_Ttt_day03.k23cnt3_Ttt_day03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23cnt3TttDay03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
