package k23cnt3_Ttt_day03.k23cnt3_Ttt_day03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23cnt3TttDay03Application {

	public static void main(String[] args) {
		SpringApplication.run(K23cnt3TttDay03Application.class, args);
        System.out.println("k23cnt3_Ttt_2310900043");
	}

}
